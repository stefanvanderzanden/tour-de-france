--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.3 (Debian 13.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tourdefrance_db;
--
-- Name: tourdefrance_db; Type: DATABASE; Schema: -; Owner: tourdefrance
--

CREATE DATABASE tourdefrance_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE tourdefrance_db OWNER TO tourdefrance;

\connect tourdefrance_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO tourdefrance;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO tourdefrance;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO tourdefrance;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO tourdefrance;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO tourdefrance;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO tourdefrance;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO tourdefrance;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO tourdefrance;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO tourdefrance;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO tourdefrance;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO tourdefrance;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO tourdefrance;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO tourdefrance;

--
-- Name: games_participantteam; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_participantteam (
    id bigint NOT NULL,
    round_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.games_participantteam OWNER TO tourdefrance;

--
-- Name: games_participantteam_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_participantteam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_participantteam_id_seq OWNER TO tourdefrance;

--
-- Name: games_participantteam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_participantteam_id_seq OWNED BY public.games_participantteam.id;


--
-- Name: games_participantteam_riders; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_participantteam_riders (
    id bigint NOT NULL,
    participantteam_id bigint NOT NULL,
    riderforteam_id bigint NOT NULL
);


ALTER TABLE public.games_participantteam_riders OWNER TO tourdefrance;

--
-- Name: games_participantteam_riders_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_participantteam_riders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_participantteam_riders_id_seq OWNER TO tourdefrance;

--
-- Name: games_participantteam_riders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_participantteam_riders_id_seq OWNED BY public.games_participantteam_riders.id;


--
-- Name: games_scoretableentryforround; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_scoretableentryforround (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    score integer NOT NULL,
    round_id bigint NOT NULL
);


ALTER TABLE public.games_scoretableentryforround OWNER TO tourdefrance;

--
-- Name: games_scoretableentryforround_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_scoretableentryforround_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_scoretableentryforround_id_seq OWNER TO tourdefrance;

--
-- Name: games_scoretableentryforround_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_scoretableentryforround_id_seq OWNED BY public.games_scoretableentryforround.id;


--
-- Name: games_stagescoreforparticipantteam; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_stagescoreforparticipantteam (
    id bigint NOT NULL,
    participant_team_id bigint NOT NULL,
    stage_id bigint NOT NULL,
    accumulated_score integer NOT NULL,
    score_for_stage integer NOT NULL
);


ALTER TABLE public.games_stagescoreforparticipantteam OWNER TO tourdefrance;

--
-- Name: games_stagescoreforparticipantteam_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_stagescoreforparticipantteam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_stagescoreforparticipantteam_id_seq OWNER TO tourdefrance;

--
-- Name: games_stagescoreforparticipantteam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_stagescoreforparticipantteam_id_seq OWNED BY public.games_stagescoreforparticipantteam.id;


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_stagescoreforparticipantteam_rider_stage_scores (
    id bigint NOT NULL,
    stagescoreforparticipantteam_id bigint NOT NULL,
    stagescoreforrider_id bigint NOT NULL
);


ALTER TABLE public.games_stagescoreforparticipantteam_rider_stage_scores OWNER TO tourdefrance;

--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_stagescoreforparticipantteam_rider_stage_scores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_stagescoreforparticipantteam_rider_stage_scores_id_seq OWNER TO tourdefrance;

--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_stagescoreforparticipantteam_rider_stage_scores_id_seq OWNED BY public.games_stagescoreforparticipantteam_rider_stage_scores.id;


--
-- Name: games_stagescoreforrider; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.games_stagescoreforrider (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    score integer NOT NULL,
    stage_id bigint NOT NULL,
    rider_id bigint NOT NULL
);


ALTER TABLE public.games_stagescoreforrider OWNER TO tourdefrance;

--
-- Name: games_stagescoreforrider_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.games_stagescoreforrider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_stagescoreforrider_id_seq OWNER TO tourdefrance;

--
-- Name: games_stagescoreforrider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.games_stagescoreforrider_id_seq OWNED BY public.games_stagescoreforrider.id;


--
-- Name: races_day; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_day (
    id bigint NOT NULL,
    date date NOT NULL,
    polymorphic_ctype_id integer,
    round_id bigint NOT NULL
);


ALTER TABLE public.races_day OWNER TO tourdefrance;

--
-- Name: races_day_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_day_id_seq OWNER TO tourdefrance;

--
-- Name: races_day_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_day_id_seq OWNED BY public.races_day.id;


--
-- Name: races_restday; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_restday (
    day_ptr_id bigint NOT NULL,
    number integer NOT NULL
);


ALTER TABLE public.races_restday OWNER TO tourdefrance;

--
-- Name: races_rider; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_rider (
    id bigint NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    birth_date date NOT NULL,
    country character varying(2) NOT NULL
);


ALTER TABLE public.races_rider OWNER TO tourdefrance;

--
-- Name: races_rider_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_rider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_rider_id_seq OWNER TO tourdefrance;

--
-- Name: races_rider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_rider_id_seq OWNED BY public.races_rider.id;


--
-- Name: races_riderforteam; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_riderforteam (
    id bigint NOT NULL,
    team_leader boolean NOT NULL,
    number integer NOT NULL,
    sprint_quality integer NOT NULL,
    climb_quality integer NOT NULL,
    attack_quality integer NOT NULL,
    is_active boolean NOT NULL,
    rider_id bigint NOT NULL,
    team_id bigint NOT NULL
);


ALTER TABLE public.races_riderforteam OWNER TO tourdefrance;

--
-- Name: races_riderforteam_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_riderforteam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_riderforteam_id_seq OWNER TO tourdefrance;

--
-- Name: races_riderforteam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_riderforteam_id_seq OWNED BY public.races_riderforteam.id;


--
-- Name: races_round; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_round (
    id bigint NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    type character varying(15) NOT NULL
);


ALTER TABLE public.races_round OWNER TO tourdefrance;

--
-- Name: races_round_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_round_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_round_id_seq OWNER TO tourdefrance;

--
-- Name: races_round_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_round_id_seq OWNED BY public.races_round.id;


--
-- Name: races_stageday; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_stageday (
    day_ptr_id bigint NOT NULL,
    number integer NOT NULL,
    start_city character varying(100) NOT NULL,
    end_city character varying(100) NOT NULL,
    distance numeric(4,1) NOT NULL,
    stage_type character varying(32) NOT NULL
);


ALTER TABLE public.races_stageday OWNER TO tourdefrance;

--
-- Name: races_stageresult; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_stageresult (
    id bigint NOT NULL,
    stage_id bigint NOT NULL,
    "position" integer NOT NULL,
    rider_id bigint NOT NULL
);


ALTER TABLE public.races_stageresult OWNER TO tourdefrance;

--
-- Name: races_stageresult_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_stageresult_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_stageresult_id_seq OWNER TO tourdefrance;

--
-- Name: races_stageresult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_stageresult_id_seq OWNED BY public.races_stageresult.id;


--
-- Name: races_team; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_team (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.races_team OWNER TO tourdefrance;

--
-- Name: races_team_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_team_id_seq OWNER TO tourdefrance;

--
-- Name: races_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_team_id_seq OWNED BY public.races_team.id;


--
-- Name: races_teamforround; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.races_teamforround (
    id bigint NOT NULL,
    round_id bigint NOT NULL,
    team_id bigint NOT NULL
);


ALTER TABLE public.races_teamforround OWNER TO tourdefrance;

--
-- Name: races_teamforround_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.races_teamforround_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_teamforround_id_seq OWNER TO tourdefrance;

--
-- Name: races_teamforround_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.races_teamforround_id_seq OWNED BY public.races_teamforround.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    email character varying(254) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.users_user OWNER TO tourdefrance;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO tourdefrance;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO tourdefrance;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO tourdefrance;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: tourdefrance
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO tourdefrance;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourdefrance
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO tourdefrance;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourdefrance
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: games_participantteam id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam ALTER COLUMN id SET DEFAULT nextval('public.games_participantteam_id_seq'::regclass);


--
-- Name: games_participantteam_riders id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam_riders ALTER COLUMN id SET DEFAULT nextval('public.games_participantteam_riders_id_seq'::regclass);


--
-- Name: games_scoretableentryforround id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_scoretableentryforround ALTER COLUMN id SET DEFAULT nextval('public.games_scoretableentryforround_id_seq'::regclass);


--
-- Name: games_stagescoreforparticipantteam id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam ALTER COLUMN id SET DEFAULT nextval('public.games_stagescoreforparticipantteam_id_seq'::regclass);


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam_rider_stage_scores ALTER COLUMN id SET DEFAULT nextval('public.games_stagescoreforparticipantteam_rider_stage_scores_id_seq'::regclass);


--
-- Name: games_stagescoreforrider id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforrider ALTER COLUMN id SET DEFAULT nextval('public.games_stagescoreforrider_id_seq'::regclass);


--
-- Name: races_day id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_day ALTER COLUMN id SET DEFAULT nextval('public.races_day_id_seq'::regclass);


--
-- Name: races_rider id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_rider ALTER COLUMN id SET DEFAULT nextval('public.races_rider_id_seq'::regclass);


--
-- Name: races_riderforteam id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_riderforteam ALTER COLUMN id SET DEFAULT nextval('public.races_riderforteam_id_seq'::regclass);


--
-- Name: races_round id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_round ALTER COLUMN id SET DEFAULT nextval('public.races_round_id_seq'::regclass);


--
-- Name: races_stageresult id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageresult ALTER COLUMN id SET DEFAULT nextval('public.races_stageresult_id_seq'::regclass);


--
-- Name: races_team id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_team ALTER COLUMN id SET DEFAULT nextval('public.races_team_id_seq'::regclass);


--
-- Name: races_teamforround id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_teamforround ALTER COLUMN id SET DEFAULT nextval('public.races_teamforround_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3241.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3243.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3239.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3251.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3237.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3235.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: games_participantteam; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_participantteam (id, round_id, user_id) FROM stdin;
\.
COPY public.games_participantteam (id, round_id, user_id) FROM '$$PATH$$/3269.dat';

--
-- Data for Name: games_participantteam_riders; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_participantteam_riders (id, participantteam_id, riderforteam_id) FROM stdin;
\.
COPY public.games_participantteam_riders (id, participantteam_id, riderforteam_id) FROM '$$PATH$$/3273.dat';

--
-- Data for Name: games_scoretableentryforround; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_scoretableentryforround (id, "position", score, round_id) FROM stdin;
\.
COPY public.games_scoretableentryforround (id, "position", score, round_id) FROM '$$PATH$$/3271.dat';

--
-- Data for Name: games_stagescoreforparticipantteam; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_stagescoreforparticipantteam (id, participant_team_id, stage_id, accumulated_score, score_for_stage) FROM stdin;
\.
COPY public.games_stagescoreforparticipantteam (id, participant_team_id, stage_id, accumulated_score, score_for_stage) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: games_stagescoreforparticipantteam_rider_stage_scores; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_stagescoreforparticipantteam_rider_stage_scores (id, stagescoreforparticipantteam_id, stagescoreforrider_id) FROM stdin;
\.
COPY public.games_stagescoreforparticipantteam_rider_stage_scores (id, stagescoreforparticipantteam_id, stagescoreforrider_id) FROM '$$PATH$$/3280.dat';

--
-- Data for Name: games_stagescoreforrider; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.games_stagescoreforrider (id, "position", score, stage_id, rider_id) FROM stdin;
\.
COPY public.games_stagescoreforrider (id, "position", score, stage_id, rider_id) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: races_day; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_day (id, date, polymorphic_ctype_id, round_id) FROM stdin;
\.
COPY public.races_day (id, date, polymorphic_ctype_id, round_id) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: races_restday; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_restday (day_ptr_id, number) FROM stdin;
\.
COPY public.races_restday (day_ptr_id, number) FROM '$$PATH$$/3262.dat';

--
-- Data for Name: races_rider; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_rider (id, first_name, last_name, birth_date, country) FROM stdin;
\.
COPY public.races_rider (id, first_name, last_name, birth_date, country) FROM '$$PATH$$/3255.dat';

--
-- Data for Name: races_riderforteam; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_riderforteam (id, team_leader, number, sprint_quality, climb_quality, attack_quality, is_active, rider_id, team_id) FROM stdin;
\.
COPY public.races_riderforteam (id, team_leader, number, sprint_quality, climb_quality, attack_quality, is_active, rider_id, team_id) FROM '$$PATH$$/3257.dat';

--
-- Data for Name: races_round; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_round (id, start_date, end_date, type) FROM stdin;
\.
COPY public.races_round (id, start_date, end_date, type) FROM '$$PATH$$/3259.dat';

--
-- Data for Name: races_stageday; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_stageday (day_ptr_id, number, start_city, end_city, distance, stage_type) FROM stdin;
\.
COPY public.races_stageday (day_ptr_id, number, start_city, end_city, distance, stage_type) FROM '$$PATH$$/3263.dat';

--
-- Data for Name: races_stageresult; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_stageresult (id, stage_id, "position", rider_id) FROM stdin;
\.
COPY public.races_stageresult (id, stage_id, "position", rider_id) FROM '$$PATH$$/3267.dat';

--
-- Data for Name: races_team; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_team (id, name, is_active) FROM stdin;
\.
COPY public.races_team (id, name, is_active) FROM '$$PATH$$/3261.dat';

--
-- Data for Name: races_teamforround; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.races_teamforround (id, round_id, team_id) FROM stdin;
\.
COPY public.races_teamforround (id, round_id, team_id) FROM '$$PATH$$/3265.dat';

--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.users_user (id, password, last_login, is_superuser, email, first_name, last_name, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.users_user (id, password, last_login, is_superuser, email, first_name, last_name, is_staff, is_active, date_joined) FROM '$$PATH$$/3245.dat';

--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.users_user_groups (id, user_id, group_id) FROM '$$PATH$$/3247.dat';

--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: tourdefrance
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.users_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3249.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 92, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 95, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 23, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 32, true);


--
-- Name: games_participantteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_participantteam_id_seq', 6, true);


--
-- Name: games_participantteam_riders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_participantteam_riders_id_seq', 106, true);


--
-- Name: games_scoretableentryforround_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_scoretableentryforround_id_seq', 10, true);


--
-- Name: games_stagescoreforparticipantteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_stagescoreforparticipantteam_id_seq', 84, true);


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_stagescoreforparticipantteam_rider_stage_scores_id_seq', 159, true);


--
-- Name: games_stagescoreforrider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.games_stagescoreforrider_id_seq', 132, true);


--
-- Name: races_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_day_id_seq', 23, true);


--
-- Name: races_rider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_rider_id_seq', 176, true);


--
-- Name: races_riderforteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_riderforteam_id_seq', 176, true);


--
-- Name: races_round_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_round_id_seq', 1, true);


--
-- Name: races_stageresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_stageresult_id_seq', 142, true);


--
-- Name: races_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_team_id_seq', 22, true);


--
-- Name: races_teamforround_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.races_teamforround_id_seq', 22, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.users_user_id_seq', 6, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourdefrance
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: games_participantteam games_participantteam_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam
    ADD CONSTRAINT games_participantteam_pkey PRIMARY KEY (id);


--
-- Name: games_participantteam_riders games_participantteam_ri_participantteam_id_rider_5762f927_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam_riders
    ADD CONSTRAINT games_participantteam_ri_participantteam_id_rider_5762f927_uniq UNIQUE (participantteam_id, riderforteam_id);


--
-- Name: games_participantteam_riders games_participantteam_riders_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam_riders
    ADD CONSTRAINT games_participantteam_riders_pkey PRIMARY KEY (id);


--
-- Name: games_participantteam games_participantteam_user_id_round_id_1e5c1e45_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam
    ADD CONSTRAINT games_participantteam_user_id_round_id_1e5c1e45_uniq UNIQUE (user_id, round_id);


--
-- Name: games_scoretableentryforround games_scoretableentryforround_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_scoretableentryforround
    ADD CONSTRAINT games_scoretableentryforround_pkey PRIMARY KEY (id);


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores games_stagescoreforparti_stagescoreforparticipant_c0cb8d55_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam_rider_stage_scores
    ADD CONSTRAINT games_stagescoreforparti_stagescoreforparticipant_c0cb8d55_uniq UNIQUE (stagescoreforparticipantteam_id, stagescoreforrider_id);


--
-- Name: games_stagescoreforparticipantteam games_stagescoreforparticipantteam_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam
    ADD CONSTRAINT games_stagescoreforparticipantteam_pkey PRIMARY KEY (id);


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores games_stagescoreforparticipantteam_rider_stage_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam_rider_stage_scores
    ADD CONSTRAINT games_stagescoreforparticipantteam_rider_stage_scores_pkey PRIMARY KEY (id);


--
-- Name: games_stagescoreforrider games_stagescoreforrider_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforrider
    ADD CONSTRAINT games_stagescoreforrider_pkey PRIMARY KEY (id);


--
-- Name: races_day races_day_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_day
    ADD CONSTRAINT races_day_pkey PRIMARY KEY (id);


--
-- Name: races_restday races_restday_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_restday
    ADD CONSTRAINT races_restday_pkey PRIMARY KEY (day_ptr_id);


--
-- Name: races_rider races_rider_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_rider
    ADD CONSTRAINT races_rider_pkey PRIMARY KEY (id);


--
-- Name: races_riderforteam races_riderforteam_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_riderforteam
    ADD CONSTRAINT races_riderforteam_pkey PRIMARY KEY (id);


--
-- Name: races_round races_round_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_round
    ADD CONSTRAINT races_round_pkey PRIMARY KEY (id);


--
-- Name: races_stageday races_stageday_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageday
    ADD CONSTRAINT races_stageday_pkey PRIMARY KEY (day_ptr_id);


--
-- Name: races_stageresult races_stageresult_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageresult
    ADD CONSTRAINT races_stageresult_pkey PRIMARY KEY (id);


--
-- Name: races_team races_team_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_team
    ADD CONSTRAINT races_team_pkey PRIMARY KEY (id);


--
-- Name: races_teamforround races_teamforround_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_teamforround
    ADD CONSTRAINT races_teamforround_pkey PRIMARY KEY (id);


--
-- Name: races_riderforteam unique rider for team; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_riderforteam
    ADD CONSTRAINT "unique rider for team" UNIQUE (team_id, rider_id);


--
-- Name: games_stagescoreforparticipantteam unique score for participant and stage; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam
    ADD CONSTRAINT "unique score for participant and stage" UNIQUE (participant_team_id, stage_id);


--
-- Name: users_user users_user_email_key; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_email_key UNIQUE (email);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: games_participantteam_riders_participantteam_id_b64c839e; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_participantteam_riders_participantteam_id_b64c839e ON public.games_participantteam_riders USING btree (participantteam_id);


--
-- Name: games_participantteam_riders_riderforteam_id_7289b63b; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_participantteam_riders_riderforteam_id_7289b63b ON public.games_participantteam_riders USING btree (riderforteam_id);


--
-- Name: games_participantteam_round_id_d5ad2416; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_participantteam_round_id_d5ad2416 ON public.games_participantteam USING btree (round_id);


--
-- Name: games_participantteam_user_id_0659ab8a; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_participantteam_user_id_0659ab8a ON public.games_participantteam USING btree (user_id);


--
-- Name: games_scoretableentryforround_round_id_2d9f2431; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_scoretableentryforround_round_id_2d9f2431 ON public.games_scoretableentryforround USING btree (round_id);


--
-- Name: games_stagescoreforpartici_stagescoreforparticipantte_e32d0bec; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforpartici_stagescoreforparticipantte_e32d0bec ON public.games_stagescoreforparticipantteam_rider_stage_scores USING btree (stagescoreforparticipantteam_id);


--
-- Name: games_stagescoreforpartici_stagescoreforrider_id_2c405947; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforpartici_stagescoreforrider_id_2c405947 ON public.games_stagescoreforparticipantteam_rider_stage_scores USING btree (stagescoreforrider_id);


--
-- Name: games_stagescoreforparticipantteam_participant_team_id_c5e223b7; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforparticipantteam_participant_team_id_c5e223b7 ON public.games_stagescoreforparticipantteam USING btree (participant_team_id);


--
-- Name: games_stagescoreforparticipantteam_stage_id_d621b2aa; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforparticipantteam_stage_id_d621b2aa ON public.games_stagescoreforparticipantteam USING btree (stage_id);


--
-- Name: games_stagescoreforrider_rider_id_e711c98a; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforrider_rider_id_e711c98a ON public.games_stagescoreforrider USING btree (rider_id);


--
-- Name: games_stagescoreforrider_stage_id_c4d1fb05; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX games_stagescoreforrider_stage_id_c4d1fb05 ON public.games_stagescoreforrider USING btree (stage_id);


--
-- Name: races_day_polymorphic_ctype_id_c2bb6e0a; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_day_polymorphic_ctype_id_c2bb6e0a ON public.races_day USING btree (polymorphic_ctype_id);


--
-- Name: races_day_round_id_8698c268; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_day_round_id_8698c268 ON public.races_day USING btree (round_id);


--
-- Name: races_riderforteam_rider_id_90831088; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_riderforteam_rider_id_90831088 ON public.races_riderforteam USING btree (rider_id);


--
-- Name: races_riderforteam_team_id_70d8d940; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_riderforteam_team_id_70d8d940 ON public.races_riderforteam USING btree (team_id);


--
-- Name: races_stageresult_rider_id_90bbd6b3; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_stageresult_rider_id_90bbd6b3 ON public.races_stageresult USING btree (rider_id);


--
-- Name: races_stageresult_stage_id_9198ab8c; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_stageresult_stage_id_9198ab8c ON public.races_stageresult USING btree (stage_id);


--
-- Name: races_teamforround_round_id_b92e2a89; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_teamforround_round_id_b92e2a89 ON public.races_teamforround USING btree (round_id);


--
-- Name: races_teamforround_team_id_02bac585; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX races_teamforround_team_id_02bac585 ON public.races_teamforround USING btree (team_id);


--
-- Name: users_user_email_243f6e77_like; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX users_user_email_243f6e77_like ON public.users_user USING btree (email varchar_pattern_ops);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: tourdefrance
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_participantteam_riders games_participanttea_participantteam_id_b64c839e_fk_games_par; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam_riders
    ADD CONSTRAINT games_participanttea_participantteam_id_b64c839e_fk_games_par FOREIGN KEY (participantteam_id) REFERENCES public.games_participantteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_participantteam_riders games_participanttea_riderforteam_id_7289b63b_fk_races_rid; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam_riders
    ADD CONSTRAINT games_participanttea_riderforteam_id_7289b63b_fk_races_rid FOREIGN KEY (riderforteam_id) REFERENCES public.races_riderforteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_participantteam games_participantteam_round_id_d5ad2416_fk_races_round_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam
    ADD CONSTRAINT games_participantteam_round_id_d5ad2416_fk_races_round_id FOREIGN KEY (round_id) REFERENCES public.races_round(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_participantteam games_participantteam_user_id_0659ab8a_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_participantteam
    ADD CONSTRAINT games_participantteam_user_id_0659ab8a_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_scoretableentryforround games_scoretableentr_round_id_2d9f2431_fk_races_rou; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_scoretableentryforround
    ADD CONSTRAINT games_scoretableentr_round_id_2d9f2431_fk_races_rou FOREIGN KEY (round_id) REFERENCES public.races_round(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforparticipantteam games_stagescoreforp_participant_team_id_c5e223b7_fk_games_par; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam
    ADD CONSTRAINT games_stagescoreforp_participant_team_id_c5e223b7_fk_games_par FOREIGN KEY (participant_team_id) REFERENCES public.games_participantteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforparticipantteam games_stagescoreforp_stage_id_d621b2aa_fk_races_sta; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam
    ADD CONSTRAINT games_stagescoreforp_stage_id_d621b2aa_fk_races_sta FOREIGN KEY (stage_id) REFERENCES public.races_stageday(day_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores games_stagescoreforp_stagescoreforpartici_e32d0bec_fk_games_sta; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam_rider_stage_scores
    ADD CONSTRAINT games_stagescoreforp_stagescoreforpartici_e32d0bec_fk_games_sta FOREIGN KEY (stagescoreforparticipantteam_id) REFERENCES public.games_stagescoreforparticipantteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforparticipantteam_rider_stage_scores games_stagescoreforp_stagescoreforrider_i_2c405947_fk_games_sta; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforparticipantteam_rider_stage_scores
    ADD CONSTRAINT games_stagescoreforp_stagescoreforrider_i_2c405947_fk_games_sta FOREIGN KEY (stagescoreforrider_id) REFERENCES public.games_stagescoreforrider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforrider games_stagescoreforr_rider_id_e711c98a_fk_races_rid; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforrider
    ADD CONSTRAINT games_stagescoreforr_rider_id_e711c98a_fk_races_rid FOREIGN KEY (rider_id) REFERENCES public.races_riderforteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: games_stagescoreforrider games_stagescoreforr_stage_id_c4d1fb05_fk_races_sta; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.games_stagescoreforrider
    ADD CONSTRAINT games_stagescoreforr_stage_id_c4d1fb05_fk_races_sta FOREIGN KEY (stage_id) REFERENCES public.races_stageday(day_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_day races_day_polymorphic_ctype_id_c2bb6e0a_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_day
    ADD CONSTRAINT races_day_polymorphic_ctype_id_c2bb6e0a_fk_django_co FOREIGN KEY (polymorphic_ctype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_day races_day_round_id_8698c268_fk_races_round_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_day
    ADD CONSTRAINT races_day_round_id_8698c268_fk_races_round_id FOREIGN KEY (round_id) REFERENCES public.races_round(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_restday races_restday_day_ptr_id_8f5c1a55_fk_races_day_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_restday
    ADD CONSTRAINT races_restday_day_ptr_id_8f5c1a55_fk_races_day_id FOREIGN KEY (day_ptr_id) REFERENCES public.races_day(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_riderforteam races_riderforteam_rider_id_90831088_fk_races_rider_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_riderforteam
    ADD CONSTRAINT races_riderforteam_rider_id_90831088_fk_races_rider_id FOREIGN KEY (rider_id) REFERENCES public.races_rider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_riderforteam races_riderforteam_team_id_70d8d940_fk_races_teamforround_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_riderforteam
    ADD CONSTRAINT races_riderforteam_team_id_70d8d940_fk_races_teamforround_id FOREIGN KEY (team_id) REFERENCES public.races_teamforround(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_stageday races_stageday_day_ptr_id_79745a46_fk_races_day_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageday
    ADD CONSTRAINT races_stageday_day_ptr_id_79745a46_fk_races_day_id FOREIGN KEY (day_ptr_id) REFERENCES public.races_day(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_stageresult races_stageresult_rider_id_90bbd6b3_fk_races_riderforteam_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageresult
    ADD CONSTRAINT races_stageresult_rider_id_90bbd6b3_fk_races_riderforteam_id FOREIGN KEY (rider_id) REFERENCES public.races_riderforteam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_stageresult races_stageresult_stage_id_9198ab8c_fk_races_sta; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_stageresult
    ADD CONSTRAINT races_stageresult_stage_id_9198ab8c_fk_races_sta FOREIGN KEY (stage_id) REFERENCES public.races_stageday(day_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_teamforround races_teamforround_round_id_b92e2a89_fk_races_round_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_teamforround
    ADD CONSTRAINT races_teamforround_round_id_b92e2a89_fk_races_round_id FOREIGN KEY (round_id) REFERENCES public.races_round(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: races_teamforround races_teamforround_team_id_02bac585_fk_races_team_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.races_teamforround
    ADD CONSTRAINT races_teamforround_team_id_02bac585_fk_races_team_id FOREIGN KEY (team_id) REFERENCES public.races_team(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tourdefrance
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

